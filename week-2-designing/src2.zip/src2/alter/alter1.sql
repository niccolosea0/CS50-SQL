-- Demonstrates renaming a table
-- Uses mbta.db

-- Renames "vists" table to "swipes"
ALTER TABLE "visits" RENAME TO "swipes";
