-- Demonstrates adding a column to a table
-- Uses mbta.db

-- Adds "ttpe" column to "swipes" table (intentional typo)
ALTER TABLE "swipes" ADD COLUMN "ttpe" TEXT;
