-- Demonstrates removing a table
-- Uses mbta.db

-- Removes riders table
DROP TABLE "riders";
