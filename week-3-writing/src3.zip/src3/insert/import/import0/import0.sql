-- Import into an existing table by specifying mode and skipping header columns
.import --csv --skip 1 mfa.csv collections