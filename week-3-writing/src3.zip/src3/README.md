schemas/insert/schema.sql\\
insert/insert0.sql\\
insert/insert1.sql\\
insert/import0/import0.sql\\
insert/import1/import1.sql\\

schemas/delete/schema0.sql\\
delete/delete0.sql\\
schemas/delete/schema1.sql\\
delete/delete1.sql\\
schemas/delete/schema2.sql\\
delete/delete2.sql\\

schemas/update/schema.sql\\
update/update0.sql\\
update/update1.sql\\

schemas/triggers/schema.sql\\
triggers/triggers.sql\\
delete/soft/delete.sql\\
